export const BULUNTU_YERI_OPTIONS = [
  { value: "", label: "Seçiniz..." },
  { value: "ALAN-1", label: "Alan 1" },
  { value: "ALAN-2", label: "Alan 2" },
  { value: "HENDEK-A", label: "Hendek A" },
  { value: "HENDEK-B", label: "Hendek B" }
];
